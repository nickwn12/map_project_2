census-regions
==============

US Census Bureau Regions and Divisions by State

http://www.census.gov/geo/maps-data/maps/pdfs/reference/us_regdiv.pdf

converted to CSV.

Because pdfs suck.
